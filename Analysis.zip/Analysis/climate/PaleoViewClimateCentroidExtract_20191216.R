# This script extracts climate data from the PaleoView dataset (https://github.com/GlobalEcologyLab/PaleoView)
# to representive population "centers"
# "workspace" should be subsituted for an indivual's working directory and preferred output location
# 05/2019
# Chris Nicholson; Christopher.M.Nicholson@asu.edu

require(sp) #spatial data extension
require(rgdal) #allows you to read it different data types
require(rgeos) #analysis toolbox (intersects, buffers, unions, etc.)
require(raster) #deals with raster data; breaks raster into smaller blocks

# open your working directory
setwd("workspace")

#bring in the area centroids; these are shapefiles
centroids<- readOGR(dsn="workspace", layer="Centroids")
spTransform(centroids, CRSobj = "+proj=longlat +datum=WGS84") 
plot(centroids)

####################################################################################
#create raster stacks for each climate variable (ppt = Average Annual Precipitation, 
#temp= average annual temperature, NPP = net primary productivity)

ppt<- dir("workspace", pattern = ".asc$") 
#get stack of rasters
setwd("workspace") 
PPtstack<- stack(ppt)

temp<- dir("workspace", pattern = ".asc$") 
#get stack of rasters
setwd("workspace") 
Tempstack<- stack(temp)

NPP<- dir("workspace", pattern = ".asc$") 
#get stack of rasters
setwd("workspace") 
NPPstack<- stack(NPP)


#extract data to points then write/export data to a csv file
TempCentroids<- data.frame(extract(Tempstack,centroids))
write.csv(TempCentroids, file = "workspace")

PPTCentroids<- data.frame(extract(PPtstack,centroids))
write.csv(PPTCentroids, file = "workspace")

NPPCentroids<- data.frame(extract(NPPstack,centroids))
write.csv(NPPCentroids, file = "workspace")
