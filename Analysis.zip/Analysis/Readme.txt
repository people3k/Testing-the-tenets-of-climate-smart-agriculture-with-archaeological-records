This file containes processed data from ``Testing the tenets of climate-smart agriculture with archaeological records." DistAnalysis.R provides rudimentary code for analyzing the data.
The graphs files contains some basic graphs. The climate file contains the modeled climate data output from Paleoview. 

Variable Definintions for Vernal50DistRed.csv. This is the main file that we used in our analysis. DistAnalysis.R calls the other files for sensitivity analyses.

Amp--The absolutve value of growth rate at the midpoint of a given histogram bin
Count--The frequency of observations in a given histogram bin of growth rates
Region--Study region
Proportion--Proportion of growth rate observations in a given histogram bin with midpoint x.
Alpha--Scaling coefficients that relates the log(Amp) to the log(Proportion) of fluctuations from a mixed effects model.
MaxAmp--he largest absolute value of observed growth rate
Complex--A relative ranking of the cases by political-economic complexity. 1=highest; 6=lowest
SpecialID--Categorial variable that documents either a technological or ecological intensification pathway for a given case study.
NegAmp--The lowest negative growth rate (i.e., collapse).
CVTemp--Coefficient of variation of a modeled temperature time-series in each region.
CVPrecip----Coefficient of variation of a modeled precipitation time-series in each region
GrCoeffAg--Coefficients of an exponential mixed effects model for the agriculture portions of time-series. Basically, documents the between case variation in the coefficient of the model: log(SPD)~a+b*(bp) +v_{i1}x_{ij}+\epsilon_{ij}. A linerarized exponential model in which we allow for random variation in the slopes and intercepts of the model by region.
NDates--Number of radiocarbon dates from a given region
ArchInten--A ranking of the cases based on the intensity of archaeological excavation in each region. 1=most excavation; 6=least excavation
