library(ggplot2)
library(reshape)
library(psych)
library(ggpubr)
library(plyr)
library(RColorBrewer)
library(splines)

library(nlme)
library(effects)
library(xtable)

##Set woirking directory

##This is a very simple analysis that uses well established r-packages.

#Load data
#50 year summed bins
amp<-read.csv(file="Vernal50DistRed.csv", header=T)
#30 year summed bins
amp<-read.csv(file="VernalDistAg30.csv", header=T)
#100 year summed bins
amp<-read.csv(file="Vernal100DistRed.csv", header=T)


##First we run mixed effects models for for the 50 year SPD sums. To check the consistency of results
#with 30 and 100 year sums, simply change the data to amp30 or amp100.

##Systematically construct the mixed effects models
#simple intercept model
intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp)
##A model with random intercepts
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|SpecialID,  method="ML", control=list(opt="optim"), data=amp)
##A random intercept model with a fixed slope
TimeRI<-update(randomIntercept,.~.+log(Amp))
#A regression model with random intercept and slopes
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|SpecialID)

#Evaluate the fits of the above models
ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
#export anova table to latex
xtable(ModelComp)

###Plot the curves from the best fitting model above over the real data

newdat <- expand.grid(SpecialID=unique(amp$SpecialID),
                      Amp=c(min(amp$Amp),
                            max(amp$Amp)))


p <- ggplot(amp, aes(x=log(Amp), y=log(Proportion), colour=factor(SpecialID))) +
  geom_point(aes(shape=factor(SpecialID))) + 
  geom_line(aes(y=predict(TimeRS), group=SpecialID)) +
  geom_line(data=newdat, aes(y=predict(TimeRS, level=0, newdata=newdat))) +
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "log Absolute value of growth rate", y="log Proportion of observations")
p

###Variation in the random coefficients
coef(TimeRS)
###Summary of the coefficients, model fit, etc of the best fitting model. In this case, TimeRS
summary(TimeRS)


######Check for variation in alpha by region
intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp)
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|Region,  method="ML", control=list(opt="optim"), data=amp)
TimeRI<-update(randomIntercept,.~.+log(Amp))
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|Region)

ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
xtable(ModelComp)

fit<-predict(TimeRS, interval = 'confidence')

DenBio.predict <- cbind(amp, fit)

# plot the points (actual observations), regression line, and confidence interval
p <- ggplot(DenBio.predict, aes(log(Amp),log(Proportion)))
p <- p + geom_point(shape=15,aes(color=factor(SpecialID), size=factor(SpecialID)))
#p <-p+scale_size_manual(values=c(3,2,2,4))
p <- p + geom_line(aes(log(Amp), fit))+
  #p <- p + geom_ribbon(aes(ymin=lwr,ymax=upr), alpha=0.3)+
  #stat_function(fun=f, colour="Treat")+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.5), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "ln size of fluctuation", y="ln Proportion of fluctuation")+
  facet_wrap(~factor(Region))
p

##Call the random coefficients associated with log(Amp)
RS<-coef(TimeRS)
#Export these coefficents into a letex table
xtable(RS)
##Call a summary of the best fitting model. 
summary(TimeRS)



###The graphs below explore the relationship between Alpha and the most intense growth rates (either abslute value or
#most negative value in the case of callapse). 

p<-ggplot(amp50, aes((MaxAmp), (alpha), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=4)+
  geom_text(vadjust=.01, nudge_y = 0.01)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Maximum absolute amplitude of change", y="Sensitivity (scaling coefficient alpha)")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))

p<-ggplot(amp50, aes((NegAmp), (alpha), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=4)+
  geom_text(vadjust=.01, nudge_y = 0.01)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Minimum negative amplitude of change", y="Sensitivity (scaling coefficient alpha)")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))
p<-ggplot(amp50, aes((Complex), (alpha), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=4)+
  geom_text(vadjust=.01, nudge_y = 0.01)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Social complexity ranking", y="Sensitivity (scaling coefficient alpha)")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))

#Graphs of social complexity ranking vs. largest amplitude of radiocarbon fluctuation

p<-ggplot(amp50, aes((Complex), (MaxAmp), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=3)+
  # geom_label(aes(fill = factor(SpecialID)), colour = "white", fontface = "bold")+
  geom_text(vadjust=.01, nudge_y = 0.0005)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Social complexity ranking", y="Maximum absolute amplitude of change")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))

p<-ggplot(amp50, aes((Complex), (NegAmp), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=3)+
  # geom_label(aes(fill = factor(SpecialID)), colour = "white", fontface = "bold")+
  geom_text(vadjust=.01, nudge_y = 0.0005)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Social complexity ranking", y="Minimum negative amplitude of change")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))

#Complexity vs. alpha

p<-ggplot(amp50, aes((Complex), (alpha), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=3)+
  # geom_label(aes(fill = factor(SpecialID)), colour = "white", fontface = "bold")+
  geom_text(vadjust=.01, nudge_y = 0.0005)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Social complexity ranking", y="Sensitivity (scaling coefficient alpha)")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))



##Explore climate and number of dates against variation in aplpha###

  ####Stability of temperature vs. alpha
p<-ggplot(amp50, aes((1/CVTemp), (alpha), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=3)+
  # geom_label(aes(fill = factor(SpecialID)), colour = "white", fontface = "bold")+
  geom_text(vadjust=.01, nudge_y = 0.0005)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Temperature stability", y="Sensitivity (scaling coefficient alpha)")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))

##stability of precipitation vs. alpha
p<-ggplot(amp50, aes((1/CVPrecip), (alpha), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=3)+
  # geom_label(aes(fill = factor(SpecialID)), colour = "white", fontface = "bold")+
  geom_text(vadjust=.01, nudge_y = 0.0005)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Precipitation stability", y="Minimum negative amplitude of change")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))

#stability of temp vs. most intense negative growth rate
p<-ggplot(amp50, aes((1/CVTemp), (NegAmp), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=3)+
  # geom_label(aes(fill = factor(SpecialID)), colour = "white", fontface = "bold")+
  geom_text(vadjust=.01, nudge_y = 0.0005)+
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "Temperature stability", y="Minimum negative amplitude of change")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))


#number of dates vs. most intense negative growth rate
p<-ggplot(amp50, aes((NDates), (alpha), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=4)+
  geom_text(vadjust=.01, nudge_y = 0.01)+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.3), colour = "black"), axis.title=element_text(size=20))+
  labs(x = "Number of radiocarbon ages", y="Sensitivity (scaling coefficient alpha)")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))


#Intensity of archaeological work vs. alpha
p<-ggplot(amp50, aes((ArchInten), (alpha), label =factor(Region))) 
p+ aes(shape=factor(SpecialID), color=factor(SpecialID)) +
  geom_point(size=4)+
  geom_text(vadjust=.01, nudge_y = 0.01)+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.3), colour = "black"), axis.title=element_text(size=20))+
  labs(x = "Intensity of archaeological research", y="Sensitivity (scaling coefficient alpha)")+
  geom_smooth(method="lm", se=0.95)
#facet_wrap(~factor(amp50$Region))


###Conduct the mixed effects model analysis for the hunter-gatherer portions of the time series.
###We conduct the analysis here on 50 year summed SPDs

amp50<-read.csv(file="HGDistRed50.csv", header=T)
amp100<-read.csv(file="100HGDist.csv", header=T)

##First we run mixed effects models for for the 50 year SPD sums. To check the consistency of results
#with 30 and 100 year sums, simply change the data to amp30 or amp100.

##Systematically construct the mixed effects models
#simple intercept model
intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp50)
##A model with random intercepts
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|SpecialID,  method="ML", control=list(opt="optim"), data=amp50)
##A random intercept model with a fixed slope
TimeRI<-update(randomIntercept,.~.+log(Amp))
#A regression model with random intercept and slopes
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|SpecialID)

#Evaluate the fits of the above models
ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
#export anova table to latex
xtable(ModelComp)

###Plot the curves from the best fitting model above over the real data

newdat <- expand.grid(SpecialID=unique(amp50$SpecialID),
                      Amp=c(min(amp50$Amp),
                            max(amp50$Amp)))


p <- ggplot(amp50, aes(x=log(Amp), y=log(Proportion), colour=factor(SpecialID))) +
  geom_point(aes(shape=factor(SpecialID))) + 
  geom_line(aes(y=predict(TimeRS), group=SpecialID)) +
  geom_line(data=newdat, aes(y=predict(TimeRS, level=0, newdata=newdat))) +
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "log Absolute value of growth rate", y="log Proportion of observations")
p

###Variation in the random coefficients
coef(TimeRS)
###Summary of the coefficients, model fit, etc of the best fitting model.
summary(TimeRS)


######Check for variation in alpha by region
intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp50)
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|Region,  method="ML", control=list(opt="optim"), data=amp50)
TimeRI<-update(randomIntercept,.~.+log(Amp))
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|Region)

ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
xtable(ModelComp)

fit<-predict(TimeRS, interval = 'confidence')

DenBio.predict <- cbind(amp50, fit)

# plot the points (actual observations), regression line, and confidence interval
p <- ggplot(DenBio.predict, aes(log(Amp),log(Proportion)))
p <- p + geom_point(shape=15,aes(color=factor(SpecialID), size=factor(SpecialID)))
#p <-p+scale_size_manual(values=c(3,2,2,4))
p <- p + geom_line(aes(log(Amp), fit))+
  #p <- p + geom_ribbon(aes(ymin=lwr,ymax=upr), alpha=0.3)+
  #stat_function(fun=f, colour="Treat")+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.5), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "ln size of fluctuation", y="ln Proportion of fluctuation")+
  facet_wrap(~factor(Region))
p

##Call the random coefficients associated with log(Amp)
RS<-coef(TimeRS)
#Export these coefficents into a letex table
xtable(RS)
##Call a summary of the best fitting model. 
summary(TimeRS)


###Analyze different growth rate (t-1 - t) for 50 year summed SPDS: sensitivity to disturbance (robustness)

##Read data
amp100<-read.csv(file="Diff250Dist.csv", header=T)

##Basic exploratory scatter plot
ggplot(amp100, aes(log(Amp), log(Proportion))) +
  geom_point(aes(color=factor(Region))) +
  theme_bw() +
  theme(axis.text.x = element_text(size=14, colour = "black"), axis.title.x=element_text(size=18),
        axis.title.y=element_text(size=18), axis.text.y = element_text( 
          size=14))+
  labs(x = "log Size of fluctuation", y="log Proportion of fluctuations")+
  #geom_point(aes(colour=factor(dir)))+
  #scale_colour_manual(name= c("First Difference"), labels =c("decrease", "increase"), values=c("red","green"))+
  #geom_hline(yintercept = mean(keep$value))+
  #scale_x_reverse()+
  geom_smooth(method='lm', se=.95)+
  facet_wrap(~factor(amp100$Region))+
  theme(strip.text.x = element_text(size = 14, colour = "black"))


##Mixed effects analysis
intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp100)
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|SpecialID,  method="ML", control=list(opt="optim"), data=amp100)
TimeRI<-update(randomIntercept,.~.+log(Amp))
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|SpecialID)

ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
xtable(ModelComp)
RE<-random.effects(TimeRS)
plot(RE)
Int<-intervals(TimeRS)
Int

newdat <- expand.grid(SpecialID=unique(amp100$SpecialID),
                      Amp=c(min(amp100$Amp),
                            max(amp100$Amp)))


p <- ggplot(amp100, aes(x=log(Amp), y=log(Proportion), colour=factor(SpecialID))) +
  geom_point(aes(shape=factor(SpecialID))) + 
  geom_line(aes(y=predict(TimeRS), group=SpecialID)) +
  geom_line(data=newdat, aes(y=predict(TimeRS, level=0, newdata=newdat))) +
  theme_bw() +
  theme(axis.text.x = element_text(size=18, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=18))+
  labs(x = "log Absolute value of growth rate", y="log Proportion of changes")
p

coef(TimeRS)
summary(TimeRS)

plot(allEffects(TimeRS), multiline=TRUE)
TimeEffect<-(allEffects(TimeRS,xlevels=list(Round1=seq(1:6))))
TimeEffect



####Regional Variation

intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp100)
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|Region,  method="ML", control=list(opt="optim"), data=amp100)
TimeRI<-update(randomIntercept,.~.+log(Amp))
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|Region)

ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
xtable(ModelComp)
summary(TimeRI)
summary(TimeRS)
RS<-coef(TimeRS)
RS
xtable(RS)

fit<-predict(TimeRS, interval = 'confidence')

DenBio.predict <- cbind(amp100, fit)

# plot the points (actual observations), regression line, and confidence interval
p <- ggplot(DenBio.predict, aes(log(Amp),log(Proportion)))
p <- p + geom_point(shape=15,aes(color=factor(SpecialID), size=factor(SpecialID)))
#p <-p+scale_size_manual(values=c(3,2,2,4))
p <- p + geom_line(aes(log(Amp), fit))+
  #p <- p + geom_ribbon(aes(ymin=lwr,ymax=upr), alpha=0.3)+
  #stat_function(fun=f, colour="Treat")+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.5), colour = "black"), axis.title=element_text(size=24))+
  labs(x = "log Absolute value of growth rate", y="log Proportion of changes")+
  facet_wrap(~factor(Region))
p

RE<-random.effects(TimeRS)
plot(RE)
Int<-intervals(TimeRS)
Int

plot(allEffects(TimeRS), multiline=TRUE)
TimeEffect<-(allEffects(TimeRS,xlevels=list(Round1=seq(1:6))))
TimeEffect

###Analyze different growth rate log(t)/log(t+1) for 50 year summed SPDS: sensitivity to disturbance (robustness)

amp100<-read.csv(file="rDist50.csv", header=T)

#Exploratory scatter plot
ggplot(amp100, aes(log(Amp), log(Proportion))) +
  geom_point(aes(color=factor(Region))) +
  theme_bw() +
  theme(axis.text.x = element_text(size=14, colour = "black"), axis.title.x=element_text(size=18),
        axis.title.y=element_text(size=18), axis.text.y = element_text( 
          size=14))+
  labs(x = "log Size of fluctuation", y="log Proportion of fluctuations")+
  #geom_point(aes(colour=factor(dir)))+
  #scale_colour_manual(name= c("First Difference"), labels =c("decrease", "increase"), values=c("red","green"))+
  #geom_hline(yintercept = mean(keep$value))+
  #scale_x_reverse()+
  geom_smooth(method='lm', se=.95)+
  facet_wrap(~factor(amp100$Region))+
  theme(strip.text.x = element_text(size = 14, colour = "black"))


intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp100)
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|SpecialID,  method="ML", control=list(opt="optim"), data=amp100)
TimeRI<-update(randomIntercept,.~.+log(Amp))
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|SpecialID)

ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
xtable(ModelComp)
RE<-random.effects(TimeRS)
plot(RE)
Int<-intervals(TimeRS)
Int

newdat <- expand.grid(SpecialID=unique(amp100$SpecialID),
                      Amp=c(min(amp100$Amp),
                            max(amp100$Amp)))


p <- ggplot(amp100, aes(x=log(Amp), y=log(Proportion), colour=factor(SpecialID))) +
  geom_point(aes(shape=factor(SpecialID))) + 
  geom_line(aes(y=predict(TimeRS), group=SpecialID)) +
  geom_line(data=newdat, aes(y=predict(TimeRS, level=0, newdata=newdat))) +
  theme_bw() +
  theme(axis.text.x = element_text(size=18, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=18))+
  labs(x = "log Absolute value of growth rate", y="log Proportion of changes")
p

coef(TimeRS)
summary(TimeRS)



####Regional Variation

intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp100)
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|Region,  method="ML", control=list(opt="optim"), data=amp100)
TimeRI<-update(randomIntercept,.~.+log(Amp))
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|Region)

ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
xtable(ModelComp)
summary(TimeRI)
summary(TimeRS)
RS<-coef(TimeRS)
RS
xtable(RS)

fit<-predict(TimeRS, interval = 'confidence')

DenBio.predict <- cbind(amp100, fit)

# plot the points (actual observations), regression line, and confidence interval
p <- ggplot(DenBio.predict, aes(log(Amp),log(Proportion)))
p <- p + geom_point(shape=15,aes(color=factor(SpecialID), size=factor(SpecialID)))
#p <-p+scale_size_manual(values=c(3,2,2,4))
p <- p + geom_line(aes(log(Amp), fit))+
  #p <- p + geom_ribbon(aes(ymin=lwr,ymax=upr), alpha=0.3)+
  #stat_function(fun=f, colour="Treat")+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.5), colour = "black"), axis.title=element_text(size=24))+
  labs(x = "log Absolute value of growth rate", y="log Proportion of changes")+
  facet_wrap(~factor(Region))
p

RE<-random.effects(TimeRS)
plot(RE)
Int<-intervals(TimeRS)
Int

plot(allEffects(TimeRS), multiline=TRUE)
TimeEffect<-(allEffects(TimeRS,xlevels=list(Round1=seq(1:6))))
TimeEffect


