####Radiocarbon SPD construction, growth rates and growth rate distributions for Freeman et al. Dec. 2019
#``Testing the tenets of climate-smart agriculture with archaeological records." This is a People 3K working
#Paper submited for publication.


#Step #1: Constructing the SPDS. Set your working directory to the Radiocarbon directory


####Calibrate Radiocarbon Ages and Produce SPDs

##Run spd of all dates and save file as csv.
#We first used a bin size to 50 in the SPD code. This is the h parameter in the binprep function
#Second we used a bin size of 150 for the SI of the paper. One can play around. Here h=50
#This averagees ages from the same site within 1-2 human generations (See SI Appendix).
library(rcarbon)
box<- read.csv("vrenal_wkshp.csv")
mogollon <- subset(box,Region=="Mogollon")

bins <- binPrep(sites=mogollon$SiteID, ages=mogollon$date, h=50)
x <- calibrate(x=mogollon$date, errors=mogollon$sd, normalised=TRUE)
spd.Mogollon <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.Mogollon)
write.table(spd.Mogollon, file = "SPDs/bin50/Mogollon50.csv", sep = ",")

ancestpueb <- subset(box,Region=="AncestPueb")

bins <- binPrep(sites=ancestpueb$SiteID, ages=ancestpueb$date, h=50)
x <- calibrate(x=ancestpueb$date, errors=ancestpueb$sd, normalised=TRUE)
spd.AncestPueb <- spd(x, bins=bins, runm=NA,spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.AncestPueb)
write.table(spd.AncestPueb, file = "SPDs/bin50/AncestPueb50.csv", sep = ",")

fremont<- subset(box,Region=="Fremont")

bins <- binPrep(sites=fremont$SiteID, ages=fremont$date, h=50)
x <- calibrate(x=fremont$date, errors=fremont$sd, normalised=TRUE)
spd.Fremont <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.Fremont)
write.table(spd.Fremont, file = "SPDs/bin50/Fremont50.csv", sep = ",")

##Note here we change to S. American cases. We use Shcal13 calibration curve for the S. American cases.

titicaca<- subset(box,Region=="Titicaca")

bins <- binPrep(sites=titicaca$SiteID, ages=titicaca$date, h=50)
x <- calibrate(x=titicaca$date, errors=titicaca$sd, calCurves='shcal13', normalised=TRUE)
spd.Titicaca <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.Titicaca)
write.table(spd.Titicaca, file = "SPDs/bin50/TiticacaSPD50.csv", sep = ",")

chile<- subset(box,Region=="Chile")

bins <- binPrep(sites=chile$SiteID, ages=chile$date, h=50)
x <- calibrate(x=chile$date, errors=chile$sd, calCurves='shcal13', normalised=TRUE)
spd.ChileInterior <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.ChileInterior)
write.table(spd.ChileInterior, file = "SPDs/bin50/ChileInteriorSPD50.csv", sep = ",")

argentina<- subset(box,Region=="Argentina")
bins <- binPrep(sites=argentina$SiteID, ages=argentina$date, h=50)
x <- calibrate(x=argentina$date, errors=argentina$sd, calCurves='shcal13', normalised=TRUE)
spd.CWArgentina <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.CWArgentina)
write.table(spd.CWArgentina, file = "SPDs/bin50/CWArgentianSPD50.csv", sep = ",")

###Construct SPDs for 150 year bins; averaging dates together from the same site within 5 human generatios

bins <- binPrep(sites=mogollon$SiteID, ages=mogollon$date, h=150)
x <- calibrate(x=mogollon$date, errors=mogollon$sd, normalised=TRUE)
spd.Mogollon <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.Mogollon)
write.table(spd.Mogollon, file = "SPDs/bin150/Mogollon150.csv", sep = ",")

bins <- binPrep(sites=ancestpueb$SiteID, ages=ancestpueb$date, h=150)
x <- calibrate(x=ancestpueb$date, errors=ancestpueb$sd, normalised=TRUE)
spd.AncestPueb <- spd(x, bins=bins, runm=NA,spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.AncestPueb)
write.table(spd.AncestPueb, file = "SPDs/bin150/AncestPueb150.csv", sep = ",")

bins <- binPrep(sites=fremont$SiteID, ages=fremont$date, h=150)
x <- calibrate(x=fremont$date, errors=fremont$sd, normalised=TRUE)
spd.Fremont <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.Fremont)
write.table(spd.Fremont, file = "SPDs/bin150/Fremont150.csv", sep = ",")

##Note here we change to S. American cases. We use Shcal13 calibration curve for the S. American cases.


bins <- binPrep(sites=titicaca$SiteID, ages=titicaca$date, h=150)
x <- calibrate(x=titicaca$date, errors=titicaca$sd, calCurves='shcal13', normalised=TRUE)
spd.Titicaca <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.Titicaca)
write.table(spd.Titicaca, file = "SPDs/bin150/TiticacaSPD150.csv", sep = ",")


bins <- binPrep(sites=chile$SiteID, ages=chile$date, h=150)
x <- calibrate(x=chile$date, errors=chile$sd, calCurves='shcal13', normalised=TRUE)
spd.ChileInterior <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.ChileInterior)
write.table(spd.ChileInterior, file = "SPDs/bin150/ChileInteriorSPD150.csv", sep = ",")


bins <- binPrep(sites=argentina$SiteID, ages=argentina$date, h=150)
x <- calibrate(x=argentina$date, errors=argentina$sd, calCurves='shcal13', normalised=TRUE)
spd.CWArgentina <- spd(x, bins=bins, runm=NA, spdnormalised = TRUE, timeRange=c(8000,300))
plot(spd.CWArgentina)
write.table(spd.CWArgentina, file = "SPDs/bin150/CWArgentianSPD150.csv", sep = ",")


##Step #2: Sum the SPDs over different numbers of years:
#30, 50, and 100 year intervals. We use 50 as our main interval of analysis
#First load the zoo package
library(zoo)


#Load cleaned file of SPDs. You can write some code to clean the file or do it\
#in a program like excel/open office. Either way, you will want a file (already provided)
#with the date calibrated bp and SPD value for each region.

keep<-read.csv(file="SPDs/bin50/50binSPDs.csv", header=T)
# sum and save new csvs.

out30 <- rollapply(keep,30,(sum),by=30,by.column=TRUE,align='right')
write.table(out30, file = "SPDs/bin50/Full30_wide.csv", sep = ",")

# sum and save new csvs.
out50 <- rollapply(keep,50,(sum),by=50,by.column=TRUE,align='right')
write.table(out30, file = "SPDs/bin50/Full50_wide.csv", sep = ",")

# sum and save new csvs.
out100 <- rollapply(keep,100,(sum),by=100,by.column=TRUE,align='right')
write.table(out100, file = "SPDs/bin50/Full100_wide.csv", sep = ",")

##Repreat for 150 year averaged dates as well

keep<-read.csv(file="SPDs/bin150/150binSPDs.csv", header=T)
# sum and save new csvs.

out30 <- rollapply(keep,30,(sum),by=30,by.column=TRUE,align='right')
write.table(out30, file = "SPDs/bin150/Full30_wide.csv", sep = ",")

# sum and save new csvs.
out50 <- rollapply(keep,50,(sum),by=50,by.column=TRUE,align='right')
write.table(out30, file = "SPDs/bin150/Full50_wide.csv", sep = ",")

# sum and save new csvs.
out100 <- rollapply(keep,100,(sum),by=100,by.column=TRUE,align='right')
write.table(out100, file = "SPDs/bin150/Full100_wide.csv", sep = ",")

##Step #3: Clean up your summed files and add AggID, which demarcates whether a given time
#point is a hunter-gatherer or agricultural period. Calculate growth rates using the first difference: xt-xt+1, 
#where xt is an SPD value at time t and xt+1 is an SPD value one time step forward.
#Again, you can write code to do this, or you can simply calculate the first diffeerences in
#Excel or a similar program. The AggID variable is simply a 1 for agriculture and a 0 for hunter-gatherer.
#Dates for the first adoption of agriculture are provided in the supporting
#information appendix. Finally, manipulate your data into long format. #Cleaned and long format data files are provided.

##Step #4: Graph the distributions of growth rates.

#Read in the relevant SPD file summed at 30, 50, or 100 years.
keep<-read.csv(file="SPDs/bin50/50SPDs.csv", header=T)
#Order factor names by the way they are listed in the spread sheet
keep$Region <- as.character(keep$Region)
#Then turn it back into an ordered factor
keep$Region <- factor(keep$Region, levels=unique(keep$Region))

##Basic Plot of growth rates over time:

library(ggplot2)

ggplot(keep, aes((bp), (Diff))) +
  geom_line(aes(color=factor(AggID)), size=1.0) +
  theme_bw() +
  theme(axis.text.x = element_text(size=14, angle=45), axis.title.x=element_text(size=18),
        axis.title.y=element_text(size=18), axis.text.y = element_text( 
          size=14))+
  labs(x = "Years cal BP", y="First difference (growth rate)")+
  #geom_point(aes(colour=factor(dir)))+
  #scale_colour_manual(name= c("First Difference"), labels =c("decrease", "increase"), values=c("red","green"))+
  #geom_hline(yintercept = mean(keep$value))+
  scale_x_reverse(limits=c(8000, 300))+
  facet_wrap(~factor(keep$Region ))+
  theme(strip.text.x = element_text(size = 14, colour = "black"))

##Subset the data to graph basic histograms of the distribution of first differences

ancestpueb <- subset(keep,Region=="AncestPueb" & AggID==1)
mogollon<-subset(keep,Region=="Mogollon"& AggID==1)
fremont<-subset(keep,Region=="Fremont"& AggID==1)
cwargentina<-subset(keep,Region=="CWArgentina"& AggID==1)
intchile<-subset(keep,Region=="NChileInt"& AggID==1)
titicaca<-subset(keep,Region=="Titicaca"& AggID==1)

#Set the histogrm bins so that all cases are scaled the same. Play with different bihn widths to observe changes
#in the shapes of the histograms. Use the absolute value of the first differences. In the main paper we use a smaller
#break, i.e., by=0.0001. In general, using a larger bin value leads to a lower number of observations.
#A lower number of observations means less power to detect differences between the slopes of given power functions
#below at a p<0.05. Keep in mind that p values are arbitrary. The sensitivity of p-values to smaple size
#is one reason why we should look more at the direction of effects and consistency of effects. 

bins <- seq(0, .025, by=0.0005)

##Construct the histograms for each case.
h1 <- hist(abs(ancestpueb$Diff),breaks = bins)
h1$breaks
h1$density
h1$counts
h1$mids

h2 <- hist(abs(mogollon$Diff),breaks = bins)
h2$counts
h2$breaks
h2$density
h2$mids

h3 <- hist(abs(fremont$Diff), breaks = bins)
h3$breaks
h3$density
h3$mids

h4 <- hist(abs(cwargentina$Diff),breaks = bins)
h5 <- hist(abs(intchile$Diff),breaks = bins)
h6 <- hist(abs(titicaca$Diff),breaks = bins)

#Bind the distributions together
AmpDist<-cbind(h1$mids,h1$counts, h2$mids, h2$counts, h3$mids,h3$counts, h4$mids,h4$counts, h5$mids,h5$counts, h6$mids,h6$counts)

##Write out the table
write.table(AmpDist, file = "SPDs/bin50/Dist50Replicate.csv", sep = ",")

##Reorganize your data into long format and code for technological vs. ecological engineering. 
#Eliminate observations of zero for the distributions. The end will be a file like:

amp50<-read.csv(file="SPDs/bin50/Dist50Replicate2.csv", header=T)


#Now let's do a quick analysis to illustrate the effect of increasing the historam binwidth.
#Even when reducing the power of our analysis by using large historgam bins, 
#we still observe the expected direction of effect: 
#technological intensification leads to a more negative slope than ecological intensification.


##Load packages for a mixed effects model.
library(nlme)
library(effects)
library(xtable)
###lme function

##In genral, proportions are more sensitive to
#changes in sample size cause by making histogram nbin widths larger. This is because large enough histogram bin widths
#bunch almost all of the total observations in the first two bins. You can also use counts 
#(i.e., the number of growth rates of a given size). Counts result in models whose p-values are less sensitive to changes
#in histogram bin width. 


##Systematically construct the mixed effects models
#simple intercept model
intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp50)
##A model with random intercepts
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|SpecialID,  method="ML", control=list(opt="optim"), data=amp50)
##A random intercept model with a fixed slope
TimeRI<-update(randomIntercept,.~.+log(Amp))
#A regression model with random intercept and slopes
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|SpecialID)

#Evaluate the relative fits of the models
ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
#Export the table anova table for latex
xtable(ModelComp)

RE<-random.effects(TimeRS)
plot(RE)
Int<-intervals(TimeRS)
Int

##Plot randome effects slopes over real data
newdat <- expand.grid(SpecialID=unique(amp50$SpecialID),
                      Amp=c(min(amp50$Amp),
                            max(amp50$Amp)))


p <- ggplot(amp50, aes(x=log(Amp), y=log(Proportion), colour=factor(SpecialID))) +
  geom_point(aes(shape=factor(SpecialID))) + 
  geom_line(aes(y=predict(TimeRS), group=SpecialID)) +
  geom_line(data=newdat, aes(y=predict(TimeRS, level=0, newdata=newdat))) +
  theme_bw() +
  theme(axis.text.x = element_text(size=20, colour = "black"), axis.title.x=element_text(size=24),
        axis.title.y=element_text(size=24), axis.text.y = element_text( 
          size=20))+
  labs(x = "log Absolute value amplitude of change", y="log Proportion of changes")
p

coef(TimeRS)
summary(TimeRS)



######Check for an interaction effect with social complexity
intercept<-gls(log(Proportion) ~ 1, method="ML", control=list(opt="optim"), data=amp50)
randomIntercept<-lme(log(Proportion) ~ 1, random=~1|Region,  method="ML", control=list(opt="optim"), data=amp50)
TimeRI<-update(randomIntercept,.~.+log(Amp))
TimeRS<-update(TimeRI,.~.+log(Amp), random=~log(Amp)|Region)

ModelComp<-anova(intercept, randomIntercept, TimeRI,TimeRS)
ModelComp
xtable(ModelComp)
RE<-random.effects(TimeRS)
plot(RE)
RE
Int<-intervals(TimeRS)
Int

fit<-predict(TimeRS, interval = 'confidence')

DenBio.predict <- cbind(amp50, fit)

# plot the points (actual observations), regression line, and confidence interval
p <- ggplot(DenBio.predict, aes(log(Amp),log(Proportion)))
p <- p + geom_point(shape=15,aes(color=factor(SpecialID), size=factor(SpecialID)))
#p <-p+scale_size_manual(values=c(3,2,2,4))
p <- p + geom_line(aes(log(Amp), fit))+
  #p <- p + geom_ribbon(aes(ymin=lwr,ymax=upr), alpha=0.3)+
  #stat_function(fun=f, colour="Treat")+
  theme_bw() +
  theme(axis.text = element_text(size = rel(1.5), colour = "black"), axis.title=element_text(size=18))+
  labs(x = "ln size of fluctuation", y="log Proportion of changes")+
  facet_wrap(~factor(Region))
p

###Repeat for hunter-gatherer portions of the sequences Note that increasing or decreasing bindwidths of the histograms
#results in similar directions of effects. All cases have amost exactly the same slope.

##HG Amp Distributions==================================================================
ancestpueb <- subset(keep,Region=="AncestPueb" & AggID==0)
mogollon<-subset(keep,Region=="Mogollon"& AggID==0)
fremont<-subset(keep,Region=="Fremont"& AggID==0)
cwargentina<-subset(keep,Region=="CWArgentina"& AggID==0)
intchile<-subset(keep,Region=="NChileInt"& AggID==0)
titicaca<-subset(keep,Region=="Titicaca"& AggID==0)

#EXAMPLE KEEP
bins <- seq(0, .0015, by=0.00001)

h1 <- hist(abs(ancestpueb$Diff),breaks = bins)
h1$breaks
h1$density
h1$counts

h2 <- hist(abs(mogollon$Diff),breaks = bins)
h2$counts
h2$breaks
h2$density
h2$mids

h3 <- hist(abs(fremont$Diff), breaks = bins)
h3$breaks
h3$density
h3$mids

h4 <- hist(abs(cwargentina$Diff),breaks = bins)
h5 <- hist(abs(intchile$Diff),breaks = bins)
h6 <- hist(abs(titicaca$Diff),breaks = bins)

AmpDist<-cbind(h1$mids,h1$counts, h2$mids, h2$counts, h3$mids,h3$counts, h4$mids,h4$counts, h5$mids,h5$counts, h6$mids,h6$counts)

write.table(SWAmpDist, file = "AmpDistHG50.csv", sep = ",")


#These are the basic processes to construct the radiocarbon data to conduct our stability analysis.
#For secondary analyses, see the ``Analysis" folder.
